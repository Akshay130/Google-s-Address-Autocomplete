/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./AddressSuggestion/index.ts":
/*!************************************!*\
  !*** ./AddressSuggestion/index.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.AddressSuggestions3 = void 0;\nvar AddressSuggestions3 = /** @class */function () {\n  function AddressSuggestions3() {\n    this._selectedAddress = \"\";\n  }\n  AddressSuggestions3.prototype.init = function (context, notifyOutputChanged, state, container) {\n    this._context = context;\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._container = container;\n    this._apiKey = context.parameters.apiKey.raw || \"\";\n    // Create input element\n    this._input = document.createElement(\"input\");\n    this._input.width = context.parameters.IWidth.raw;\n    this._input.height = context.parameters.IWidth.raw;\n    this._input.type = \"text\";\n    this._input.id = \"address-input\";\n    this._container.appendChild(this._input);\n    // Load Google Places API\n    var script = document.createElement(\"script\");\n    script.src = \"https://maps.googleapis.com/maps/api/js?key=\".concat(this._apiKey, \"&libraries=places\");\n    script.async = true;\n    script.onload = this._initializeAutocomplete.bind(this);\n    this._container.appendChild(script);\n  };\n  AddressSuggestions3.prototype._initializeAutocomplete = function () {\n    // Create autocomplete object\n    this._autocomplete = new google.maps.places.Autocomplete(this._input);\n    this._autocomplete.addListener(\"place_changed\", this._handlePlaceChanged.bind(this));\n    // Add event listener to input element\n    this._input.addEventListener(\"input\", this._handleInput.bind(this));\n  };\n  AddressSuggestions3.prototype._handleInput = function () {\n    var query = this._input.value;\n    var service = new google.maps.places.AutocompleteService();\n    service.getPlacePredictions({\n      input: query\n    }, function (predictions, status) {\n      if (status === google.maps.places.PlacesServiceStatus.OK) {\n        var addresses = predictions.map(function (prediction) {\n          return prediction.description;\n        });\n        //  this._renderSuggestions(addresses);\n      } else {\n        //  this._renderSuggestions([]);\n      }\n    });\n  };\n  AddressSuggestions3.prototype._handlePlaceChanged = function () {\n    var place = this._autocomplete.getPlace();\n    if (place && place.formatted_address) {\n      this._selectedAddress = place.formatted_address;\n      this._notifyOutputChanged();\n    }\n  };\n  AddressSuggestions3.prototype._clearSuggestions = function () {\n    var suggestionsList = this._container.querySelector(\".suggestions-list\");\n    if (suggestionsList) {\n      this._container.removeChild(suggestionsList);\n    }\n  };\n  AddressSuggestions3.prototype.updateView = function (context) {\n    // No need to update view during input or place change events\n  };\n  AddressSuggestions3.prototype.getOutputs = function () {\n    return {\n      SelectedAddress: this._selectedAddress\n    };\n  };\n  AddressSuggestions3.prototype.destroy = function () {};\n  return AddressSuggestions3;\n}();\nexports.AddressSuggestions3 = AddressSuggestions3;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./AddressSuggestion/index.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./AddressSuggestion/index.ts"](0, __webpack_exports__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('addresssuggestions3.AddressSuggestions3', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.AddressSuggestions3);
} else {
	var addresssuggestions3 = addresssuggestions3 || {};
	addresssuggestions3.AddressSuggestions3 = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.AddressSuggestions3;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}